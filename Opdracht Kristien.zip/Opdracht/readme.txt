**Ik heb een block-layout geïmplementeerd, voor het menu heb ik een inline layout gebruikt.
**De buttons van het spelletje Snake heb ik in een container (div tag) geplaatst, zodat ik ze mooi kon centreren.
**De titel zit in de header tag met aparte opmaak
**Het menu zit in de nav tag
**Het spelletje/welkomstwoord zelf zit in een article tag
**Ik heb overal wat padding en margin toegevoegd om het geheel wat beter leesbaar en aantrekkelijk te houden.
